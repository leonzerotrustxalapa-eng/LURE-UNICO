#ifndef LURE_UNICO_H
#define LURE_UNICO_H
#define LURE_SELLO "LURE-LOGv1 | LEON-XALAPA | TIER_C4 | CDA2A246C493955D"
#include <stdio.h>
static inline void imprimir_sello_unico() {
    printf("================================\n");
    printf("%s\n", LURE_SELLO);
    printf("Autor: Leon Zerotrust Xalapa\n");
    printf("GPG: CDA2A246C493955D [ultimate]\n");
    printf("================================\n");
}
#endif
